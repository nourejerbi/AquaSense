# Water Quality AI Agent — Hardware Guide

## Bill of Materials

| Component | Model | Qty | Notes |
|---|---|---|---|
| Microcontroller | ESP32 DevKit v1 (38-pin) | 1 | Any ESP32 variant works |
| pH Sensor | DFRobot SEN0161 Gravity pH | 1 | Includes BNC probe + signal board |
| Turbidity Sensor | DFRobot SEN0189 | 1 | Analog, 5V supply (see voltage divider) |
| Dissolved O₂ Sensor | DFRobot SEN0237-A | 1 | Gravity DO Kit |
| Temperature Sensor | DS18B20 waterproof probe | 1 | 1-Wire, stainless steel probe |
| TDS / Conductivity | DFRobot SEN0244 Gravity TDS | 1 | Analog output |
| Nitrate Sensor | Atlas Scientific ENV-50-NIT | 1 | Or analog nitrate electrode |
| Resistor 4.7kΩ | 1/4W | 1 | DS18B20 pull-up |
| Resistor 10kΩ | 1/4W | 2 | Voltage divider for 5V sensors |
| Resistor 20kΩ | 1/4W | 2 | Voltage divider lower leg |
| Breadboard / PCB | — | 1 | For prototyping |
| USB Power Supply | 5V 2A | 1 | For ESP32 |
| Waterproof enclosure | IP67 rated | 1 | For electronics |
| Flexible cable | Silicone-jacketed | 1m | For submerged probes |

Estimated cost: ~$150–250 USD depending on sensor grades.

---

## Wiring Diagram

```
                          ┌─────────────────────────────────────┐
                          │           ESP32 DevKit v1           │
                          │                                     │
3.3V  ──────────────────→ │ 3V3          GPIO4 ─────────────── │──→ DS18B20 DATA (with 4.7kΩ to 3.3V)
GND   ──────────────────→ │ GND          GPIO34 ─────────────── │──→ pH signal out
                          │              GPIO35 ─────────────── │──→ Turbidity signal out (via divider)
                          │              GPIO32 ─────────────── │──→ DO signal out
                          │              GPIO33 ─────────────── │──→ TDS signal out
                          │              GPIO36 ─────────────── │──→ Nitrate signal out
                          └─────────────────────────────────────┘
```

### pH Sensor (SEN0161)
```
Sensor Board          ESP32
VCC  ─────────────── 3.3V (or 5V — check your module)
GND  ─────────────── GND
OUT  ─────────────── GPIO34 (ADC1_CH6)

Note: GPIO34 is input-only, 3.3V max. If sensor outputs 5V, add voltage divider:
  OUT → [10kΩ] → GPIO34 → [20kΩ] → GND   (gives 3.3V when input is 5V)
```

### Turbidity Sensor (SEN0189) — NEEDS 5V supply
```
Sensor            ESP32                    Voltage divider
VCC  ──────────── 5V (VIN pin)
GND  ──────────── GND
OUT  ─── [10kΩ] ─── GPIO35 ─── [20kΩ] ─── GND

The 10k/20k divider scales 0–5V → 0–3.3V safely.
```

### Dissolved Oxygen Sensor (SEN0237)
```
Sensor Board      ESP32
VCC  ──────────── 3.3V
GND  ──────────── GND
OUT  ──────────── GPIO32 (ADC1_CH4)
```

### DS18B20 Temperature (waterproof probe)
```
DS18B20           ESP32
VCC (red)  ─────── 3.3V
GND (black)─────── GND
DATA (yellow) ──── GPIO4  ←──┤ 4.7kΩ ├──── 3.3V
                              (pull-up resistor — REQUIRED)
```

### TDS / Conductivity Sensor (SEN0244)
```
Sensor Board      ESP32
VCC  ──────────── 3.3V
GND  ──────────── GND
OUT  ──────────── GPIO33 (ADC1_CH5)
```

### Nitrate Sensor (Atlas Scientific or analog electrode)
```
Sensor            ESP32
VCC  ──────────── 3.3V
GND  ──────────── GND
OUT  ──────────── GPIO36 (ADC1_CH0 / VP pin)
```

---

## Important Notes

### ADC Limitations on ESP32
- GPIO34, 35, 36, 39 are **input-only** — no pull-up/down resistors internally.
- ADC2 (GPIO 0, 2, 4, 12–15, 25–27) **conflicts with WiFi**. Use ADC1 pins only (GPIO 32–39).
- ESP32 ADC is 12-bit (0–4095) with reference voltage 3.3V.
- Always use `analogSetAttenuation(ADC_11db)` for full 0–3.3V range.

### Voltage Divider Formula
If sensor outputs 0–5V and ESP32 max is 3.3V:
```
Vout = Vin × R2 / (R1 + R2)
3.3  = 5.0 × 20k / (10k + 20k) = 3.33V  ✓
```
Use R1=10kΩ (top), R2=20kΩ (bottom to GND).

### Power Supply
- Run ESP32 from stable 5V 2A USB supply.
- Add 100µF capacitor across VCC/GND near ESP32 for stable ADC readings.
- Keep sensor signal wires away from power wires to reduce noise.

### Waterproofing
- Only the sensor **probes** go in water — keep the ESP32 and circuit boards dry.
- Use silicone-sealed cable glands on the enclosure for probe cables.
- Apply conformal coating to sensor boards if there is splash risk.

---

## Sensor Placement

For best readings, install sensors:
- **pH probe**: submerged 10–15cm, away from inlet flows that cause turbulence.
- **Turbidity sensor**: point away from direct sunlight; calibrate in situ.
- **DO probe**: in a flow-through chamber or gently stirred — DO readings need water movement.
- **Temperature probe**: in the main body of water, in shade.
- **TDS probe**: submerged fully; keep electrodes clean (rinse monthly).
- **Nitrate probe**: submerged; recalibrate every 2 weeks.

---

## Calibration Schedule

| Sensor | Frequency | Standards needed |
|---|---|---|
| pH | Monthly | pH 4.0 + pH 7.0 buffer |
| Turbidity | Bi-monthly | 0 NTU (DI water) + 100 NTU |
| Dissolved O₂ | Monthly | Air-saturated water |
| TDS/Conductivity | Bi-monthly | 1413 µS/cm standard |
| Nitrates | Every 2 weeks | 0 + 50 mg/L nitrate standard |
| Temperature | On setup | Verified thermometer |
