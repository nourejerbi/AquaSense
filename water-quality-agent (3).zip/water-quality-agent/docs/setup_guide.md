# Water Quality AI Agent — Setup Guide

## Project Overview

```
ESP32 (sensors) → Firebase Realtime DB → Dashboard (HTML) → Claude AI API
     ↑                    ↑                      ↑                ↑
  Reads all         Stores readings          Polls every        Classifies
  6 sensors         + history               5 seconds          + predicts
```

---

## Step 1 — Firebase Setup

### 1.1 Create a Firebase project
1. Go to https://console.firebase.google.com
2. Click **Add project** → name it (e.g. `water-quality-agent`)
3. Disable Google Analytics (not needed) → **Create project**

### 1.2 Enable Realtime Database
1. In the left sidebar: **Build → Realtime Database**
2. Click **Create database**
3. Choose a region close to you
4. Start in **test mode** (we'll add rules later)

### 1.3 Get your credentials
1. **Project Settings** (gear icon) → **General** → **Your apps**
2. Click **</> Web** to register a web app
3. Copy your `apiKey` and `databaseURL` — you'll need these in the ESP32 firmware and dashboard

### 1.4 Apply security rules
Go to **Realtime Database → Rules** and paste the contents of `backend/firebase_rules.json`.

For development/testing, you can use open rules temporarily:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
**Change this before production!**

---

## Step 2 — ESP32 Firmware

### 2.1 Install Arduino IDE dependencies
In Arduino IDE, install these libraries via **Tools → Manage Libraries**:
- `Firebase ESP Client` by Mobizt (v4.x)
- `OneWire` by Paul Stoffregen
- `DallasTemperature` by Miles Burton
- `ArduinoJson` by Benoit Blanchon (v6.x)

### 2.2 Configure the firmware
Open `esp32/water_quality_sensor.ino` and edit the top section:

```cpp
#define WIFI_SSID        "YOUR_WIFI_SSID"
#define WIFI_PASSWORD    "YOUR_WIFI_PASSWORD"
#define FIREBASE_API_KEY       "AIzaSy..."       // from Step 1.3
#define FIREBASE_DATABASE_URL  "https://your-project.firebaseio.com"
```

### 2.3 Calibrate sensors (recommended)
Before flashing the main firmware:
1. Flash `esp32/calibration_tool.ino` to your ESP32
2. Open Serial Monitor at 115200 baud
3. Follow the prompts — have your calibration standards ready
4. Calibration values are saved to NVS automatically

### 2.4 Flash the main firmware
1. Open `esp32/water_quality_sensor.ino`
2. Select your board: **Tools → Board → ESP32 Dev Module**
3. Select your port: **Tools → Port → COMx or /dev/ttyUSBx**
4. Click **Upload**
5. Open Serial Monitor — you should see WiFi connection and Firebase updates

---

## Step 3 — Dashboard

### 3.1 Open the dashboard
Simply open `dashboard/index.html` in any modern browser. No server needed.

For Firebase live data:
1. Click **Config → Firebase Setup** in the sidebar
2. Paste your Database URL and API Key
3. Click **Connect to Firebase**

### 3.2 Test with simulation
Click **Start simulation** on the Live Dashboard to generate test data without hardware.
Click **Inject pollution event** to test alert and AI classification behavior.

### 3.3 AI analysis
Click **Analyze with AI** to send current readings to Claude.
The agent will:
- Classify water as SAFE / MILDLY POLLUTED / POLLUTED
- Identify likely pollution sources
- Predict risk for 1h, 6h, 24h
- Suggest treatment/monitoring actions

---

## Step 4 — Optional: Host the dashboard

### Option A — GitHub Pages (free)
```bash
git init
git add dashboard/index.html
git commit -m "Initial dashboard"
gh repo create water-quality-agent --public
git push origin main
# Enable Pages in repo Settings → Pages → Deploy from main branch
```

### Option B — Netlify (free, drag-and-drop)
1. Go to https://netlify.com
2. Drag the `dashboard/` folder onto the deploy area
3. Done — you get a public URL instantly

### Option C — Local network (LAN only)
```bash
# Python
cd dashboard && python3 -m http.server 8080
# Node
npx serve dashboard
```
Access from any device on your local network at `http://YOUR_IP:8080`

---

## Firebase Data Structure

```
/sensors/
  latest/
    ph:               7.2
    turbidity:        3.1
    dissolved_oxygen: 8.4
    temperature:      22.1
    conductivity:     420
    nitrates:         8.2
    timestamp:        1700000000
    device_id:        "AA:BB:CC:DD:EE:FF"
  history/
    1700000000/       ← timestamped snapshots (pushed every 60s)
      ph: ...
      ...
  device_status:    "SAFE"      ← set by ESP32
  fail_count:       0
  last_seen:        "1700000000"
  firmware:         "1.0.0"
```

---

## Troubleshooting

### ESP32 not connecting to WiFi
- Double-check SSID/password (case-sensitive)
- ESP32 only supports 2.4GHz WiFi, not 5GHz
- Move closer to router for initial setup

### Firebase permission denied
- Check your Database Rules — in test mode, set both read/write to `true`
- Verify the API key is from the same project as the database URL
- Check that the database URL includes `https://` and ends with `.firebaseio.com`

### Sensor reading 0 or 4095 constantly
- Check wiring — VCC and GND first
- Verify the pin number matches your physical wiring
- Use the Serial Monitor to debug: readings print every 5 seconds
- Confirm `analogSetAttenuation(ADC_11db)` is set for 0–3.3V range

### AI analysis not working
- The Anthropic API key is injected automatically in claude.ai artifacts
- If running the dashboard locally, you need to add your own API key:
  In `index.html`, find the fetch call and add: `"x-api-key": "YOUR_KEY"`

### pH readings unstable
- Allow 2-minute warm-up time after submerging the probe
- Recalibrate with fresh buffer solutions
- Keep probe tip hydrated in KCl storage solution when not in use

---

## Project File Structure

```
water-quality-agent/
├── esp32/
│   ├── water_quality_sensor.ino   ← Main firmware (flash this)
│   └── calibration_tool.ino       ← Calibration utility
├── dashboard/
│   └── index.html                 ← Full dashboard (open in browser)
├── backend/
│   └── firebase_rules.json        ← Firebase security rules
└── docs/
    ├── hardware_guide.md          ← Wiring + BOM
    └── setup_guide.md             ← This file
```
