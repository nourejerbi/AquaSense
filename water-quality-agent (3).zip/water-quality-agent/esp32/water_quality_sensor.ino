/*
 * Water Quality AI Agent — ESP32 Firmware
 * =========================================
 * Reads: pH, Turbidity, Dissolved Oxygen, Temperature (DS18B20),
 *        Conductivity/TDS, Nitrates (analog)
 * Posts: readings to Firebase Realtime Database every READ_INTERVAL_MS
 *
 * Board: ESP32 (any variant)
 * Required libraries (install via Arduino Library Manager):
 *   - Firebase ESP Client  by Mobizt  (v4.x)
 *   - OneWire              by Paul Stoffregen
 *   - DallasTemperature    by Miles Burton
 *   - ArduinoJson          by Benoit Blanchon (v6.x)
 */

#include <WiFi.h>
#include <Firebase_ESP_Client.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

// ─── Configuration ────────────────────────────────────────────────────────────
#define WIFI_SSID        "YOUR_WIFI_SSID"
#define WIFI_PASSWORD    "YOUR_WIFI_PASSWORD"

// Firebase project settings (Project Settings → General → Your apps → SDK setup)
#define FIREBASE_API_KEY       "AIzaSyB9Q9Xx2RvOFfkMbMmwPU98H0kgrMLqT5Y"
#define FIREBASE_DATABASE_URL  "https://water-quality-agent-b500e-default-rtdb.europe-west1.firebasedatabase.app"

// Firebase Auth credentials (required for secure database access)
#define FIREBASE_USER_EMAIL    "YOUR_FIREBASE_EMAIL"
#define FIREBASE_USER_PASSWORD "YOUR_FIREBASE_PASSWORD"

// ─── Pin Assignments ──────────────────────────────────────────────────────────
#define PIN_PH          34   // pH sensor analog out → ADC1_CH6
#define PIN_TURBIDITY   35   // Turbidity sensor analog out → ADC1_CH7
#define PIN_DO          32   // Dissolved O2 sensor analog out → ADC1_CH4
#define PIN_TDS         33   // TDS/Conductivity sensor analog out → ADC1_CH5
#define PIN_NITRATE     36   // Nitrate sensor analog out → ADC1_CH0 (VP)
#define PIN_DS18B20     4    // DS18B20 temperature sensor data pin (with 4.7kΩ pull-up)

// ─── Timing ───────────────────────────────────────────────────────────────────
#define READ_INTERVAL_MS   5000    // Read sensors every 5 seconds
#define HISTORY_PUSH_MS    60000   // Push to history log every 60 seconds

// ─── Calibration constants ────────────────────────────────────────────────────
// pH: calibrate with pH 4.0 and pH 7.0 buffer solutions
// Record the ADC voltage at each known pH and adjust these values
#define PH_VOLTAGE_AT_4   2.23    // Volts when sensor reads pH 4.0
#define PH_VOLTAGE_AT_7   2.50    // Volts when sensor reads pH 7.0

// TDS: temperature compensation coefficient
#define TDS_COMP_COEFF    0.02    // 2% per °C

// DO: factory calibration offset (adjust after air calibration)
#define DO_AIR_VOLTAGE    1.627   // Voltage in air-saturated water at 25°C
#define DO_AIR_SAT        8.26    // DO mg/L in air at 25°C sea level

// ADC reference voltage and resolution
#define ADC_VREF          3.3
#define ADC_RESOLUTION    4095.0

// ─── Globals ──────────────────────────────────────────────────────────────────
FirebaseData   fbdo;
FirebaseAuth   auth;
FirebaseConfig fbConfig;

OneWire        oneWire(PIN_DS18B20);
DallasTemperature tempSensor(&oneWire);

unsigned long lastReadTime     = 0;
unsigned long lastHistoryTime  = 0;
unsigned long historyIndex     = 0;
bool          firebaseReady    = false;

struct SensorData {
  float ph;
  float turbidity;
  float dissolvedOxygen;
  float temperature;
  float conductivity;
  float nitrates;
  bool  valid;
};

// ─── Sensor reading helpers ───────────────────────────────────────────────────

float readVoltage(int pin, int samples = 10) {
  long sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += analogRead(pin);
    delayMicroseconds(100);
  }
  return (sum / (float)samples) / ADC_RESOLUTION * ADC_VREF;
}

float readPH() {
  float voltage = readVoltage(PIN_PH);
  // Linear interpolation from two-point calibration
  float slope   = (7.0 - 4.0) / (PH_VOLTAGE_AT_7 - PH_VOLTAGE_AT_4);
  float ph      = 7.0 + slope * (voltage - PH_VOLTAGE_AT_7);
  return constrain(ph, 0.0, 14.0);
}

float readTurbidity() {
  float voltage = readVoltage(PIN_TURBIDITY);
  // SEN0189 calibration curve (adjust for your sensor model)
  // Voltage decreases as turbidity increases
  float ntu;
  if (voltage < 2.5) {
    ntu = 3000.0;
  } else {
    ntu = -1120.4 * voltage * voltage + 5742.3 * voltage - 4353.8;
  }
  return max(0.0f, ntu);
}

float readDissolvedOxygen(float tempC) {
  float voltage = readVoltage(PIN_DO);
  // Temperature compensation using Benson & Krause equation
  float doSat   = 14.62 - 0.3898 * tempC + 0.006969 * tempC * tempC
                  - 0.00005696 * tempC * tempC * tempC;
  float doMgL   = (voltage / DO_AIR_VOLTAGE) * doSat;
  return constrain(doMgL, 0.0, 20.0);
}

float readTemperature() {
  tempSensor.requestTemperatures();
  float t = tempSensor.getTempCByIndex(0);
  if (t == DEVICE_DISCONNECTED_C) return -999.0;
  return t;
}

float readTDS(float tempC) {
  float voltage     = readVoltage(PIN_TDS);
  float compCoeff   = 1.0 + TDS_COMP_COEFF * (tempC - 25.0);
  float compVoltage = voltage / compCoeff;
  // TDS formula for SEN0244 sensor
  float tds = (133.42 * pow(compVoltage, 3)
              - 255.86 * pow(compVoltage, 2)
              + 857.39 * compVoltage) * 0.5;
  float conductivity = tds * 2.0; // approximate µS/cm
  return max(0.0f, conductivity);
}

float readNitrates() {
  float voltage = readVoltage(PIN_NITRATE);
  // Linear mapping — calibrate with known nitrate standard solutions
  // Typical range 0–100 mg/L nitrate-N
  float nitrate = (voltage / ADC_VREF) * 100.0;
  return constrain(nitrate, 0.0, 200.0);
}

SensorData readAllSensors() {
  SensorData d;
  d.temperature     = readTemperature();
  if (d.temperature == -999.0) {
    Serial.println("[WARN] DS18B20 not found — using 25°C fallback");
    d.temperature = 25.0;
  }
  d.ph              = readPH();
  d.turbidity       = readTurbidity();
  d.dissolvedOxygen = readDissolvedOxygen(d.temperature);
  d.conductivity    = readTDS(d.temperature);
  d.nitrates        = readNitrates();
  d.valid           = true;
  return d;
}

// ─── Firebase helpers ─────────────────────────────────────────────────────────

void pushLatest(const SensorData& d) {
  FirebaseJson json;
  json.set("ph",               d.ph);
  json.set("turbidity",        d.turbidity);
  json.set("dissolved_oxygen", d.dissolvedOxygen);
  json.set("temperature",      d.temperature);
  json.set("conductivity",     d.conductivity);
  json.set("nitrates",         d.nitrates);
  json.set("timestamp",        (int)time(nullptr));
  json.set("device_id",        WiFi.macAddress());

  if (Firebase.RTDB.setJSON(&fbdo, "/sensors/latest", &json)) {
    Serial.println("[FB] /sensors/latest updated");
  } else {
    Serial.printf("[FB] Error: %s\n", fbdo.errorReason().c_str());
  }
}

void pushHistory(const SensorData& d) {
  // Push to a timestamped history node for trend analysis
  String path = "/sensors/history/" + String(time(nullptr));
  FirebaseJson json;
  json.set("ph",               d.ph);
  json.set("turbidity",        d.turbidity);
  json.set("dissolved_oxygen", d.dissolvedOxygen);
  json.set("temperature",      d.temperature);
  json.set("conductivity",     d.conductivity);
  json.set("nitrates",         d.nitrates);
  json.set("timestamp",        (int)time(nullptr));

  if (Firebase.RTDB.setJSON(&fbdo, path.c_str(), &json)) {
    Serial.printf("[FB] History pushed to %s\n", path.c_str());
    historyIndex++;
  } else {
    Serial.printf("[FB] History error: %s\n", fbdo.errorReason().c_str());
  }
}

void updateStatus(const SensorData& d) {
  // Compute a simple local status for Firebase (AI agent refines this)
  bool phOk   = d.ph >= 6.5 && d.ph <= 8.5;
  bool turbOk = d.turbidity <= 4.0;
  bool doOk   = d.dissolvedOxygen >= 6.0;
  bool tdsOk  = d.conductivity <= 800.0;
  bool nitOk  = d.nitrates <= 50.0;
  bool tempOk = d.temperature >= 10.0 && d.temperature <= 30.0;

  int failCount = (!phOk) + (!turbOk) + (!doOk) + (!tdsOk) + (!nitOk) + (!tempOk);
  String status = failCount == 0 ? "SAFE" : failCount <= 2 ? "WARNING" : "POLLUTED";

  Firebase.RTDB.setString(&fbdo, "/sensors/device_status", status);
  Firebase.RTDB.setInt(&fbdo, "/sensors/fail_count", failCount);
  Firebase.RTDB.setString(&fbdo, "/sensors/last_seen", String(time(nullptr)));
}

// ─── Setup ────────────────────────────────────────────────────────────────────

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== Water Quality AI Agent ===");

  // Init sensors
  tempSensor.begin();
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db); // for 0–3.3V range

  // WiFi
  Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < 30) {
    delay(500);
    Serial.print(".");
    retries++;
  }
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("\n[WiFi] Failed — rebooting in 5s");
    delay(5000);
    ESP.restart();
  }
  Serial.printf("\n[WiFi] Connected — IP: %s\n", WiFi.localIP().toString().c_str());

  // NTP time sync (needed for timestamps)
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  Serial.print("[NTP] Syncing time");
  struct tm timeinfo;
  while (!getLocalTime(&timeinfo)) { delay(500); Serial.print("."); }
  Serial.println(" done");

  // Firebase
  fbConfig.api_key          = FIREBASE_API_KEY;
  fbConfig.database_url     = FIREBASE_DATABASE_URL;
  fbConfig.token_status_callback = tokenStatusCallback;

  if (strlen(FIREBASE_USER_EMAIL) > 0) {
    auth.user.email    = FIREBASE_USER_EMAIL;
    auth.user.password = FIREBASE_USER_PASSWORD;
  }

  Firebase.begin(&fbConfig, &auth);
  Firebase.reconnectWiFi(true);
  fbdo.setResponseSize(4096);

  // Wait for Firebase token
  Serial.print("[FB] Authenticating");
  int fbRetry = 0;
  while (!Firebase.ready() && fbRetry < 20) {
    delay(500);
    Serial.print(".");
    fbRetry++;
  }
  firebaseReady = Firebase.ready();
  Serial.printf("\n[FB] %s\n", firebaseReady ? "Ready" : "Failed (offline mode)");

  // Register device info
  if (firebaseReady) {
    Firebase.RTDB.setString(&fbdo, "/sensors/device_id", WiFi.macAddress());
    Firebase.RTDB.setString(&fbdo, "/sensors/firmware",  "1.0.0");
    Firebase.RTDB.setInt(&fbdo,    "/sensors/boot_time", (int)time(nullptr));
  }

  Serial.println("[BOOT] Setup complete — starting sensor loop");
}

// ─── Loop ─────────────────────────────────────────────────────────────────────

void loop() {
  unsigned long now = millis();

  if (now - lastReadTime >= READ_INTERVAL_MS) {
    lastReadTime = now;

    Serial.println("\n--- Sensor Read ---");
    SensorData d = readAllSensors();

    Serial.printf("  pH:          %.2f\n",  d.ph);
    Serial.printf("  Turbidity:   %.2f NTU\n", d.turbidity);
    Serial.printf("  DO:          %.2f mg/L\n", d.dissolvedOxygen);
    Serial.printf("  Temperature: %.2f °C\n",  d.temperature);
    Serial.printf("  Conductivity:%.0f µS/cm\n", d.conductivity);
    Serial.printf("  Nitrates:    %.2f mg/L\n", d.nitrates);

    if (firebaseReady && Firebase.ready()) {
      pushLatest(d);
      updateStatus(d);

      if (now - lastHistoryTime >= HISTORY_PUSH_MS) {
        lastHistoryTime = now;
        pushHistory(d);
      }
    } else {
      Serial.println("[FB] Offline — data not pushed");
      firebaseReady = Firebase.ready();
    }
  }

  // Keep Firebase connection alive
  Firebase.RTDB.getRules(&fbdo);
}
