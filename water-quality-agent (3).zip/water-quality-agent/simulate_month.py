import json
import urllib.request
import time
import random

url = "https://water-quality-agent-b500e-default-rtdb.europe-west1.firebasedatabase.app"
auth = "AIzaSyB9Q9Xx2RvOFfkMbMmwPU98H0kgrMLqT5Y"

def push_data(path, data):
    req = urllib.request.Request(f"{url}/{path}?auth={auth}", data=json.dumps(data).encode('utf-8'), method='PUT')
    with urllib.request.urlopen(req) as response:
        return response.read()

history = {}
now = int(time.time())

for i in range(30):
    day_offset = 30 - i
    ts = now - (day_offset * 86400)
    
    # Progress from 0.0 (clean) to 1.0 (polluted) over 30 days
    # We use a slight curve so it starts slow and accelerates
    progress = (i / 29.0) ** 1.5 
    
    ph = 7.5 - (progress * 2.0)  # Drops to 5.5 (acidic)
    turbidity = 1.0 + (progress * 18.0) # Increases to 19.0 (very muddy, safe < 4)
    do = 8.5 - (progress * 6.5)  # Drops to 2.0 (low oxygen, safe > 6)
    temp = 22.0 + (progress * 3.0) # slightly warms up
    cond = 300 + (progress * 600) # Increases to 900 (safe < 800)
    nitrate = 5.0 + (progress * 60.0) # Increases to 65.0 (safe < 50)
    
    # add random noise
    ph += random.uniform(-0.1, 0.1)
    turbidity += random.uniform(-0.5, 0.5)
    do += random.uniform(-0.2, 0.2)
    temp += random.uniform(-0.5, 0.5)
    cond += random.uniform(-10, 10)
    nitrate += random.uniform(-2, 2)

    entry = {
        "ph": round(ph, 2),
        "turbidity": round(turbidity, 1),
        "dissolved_oxygen": round(do, 1),
        "temperature": round(temp, 1),
        "conductivity": round(cond, 0),
        "nitrates": round(nitrate, 1),
        "timestamp": ts,
        "device_id": "TEST:ESP32:01"
    }
    
    history[str(ts)] = entry
    
    # Push the latest point to /sensors/latest
    if i == 29:
        push_data("sensors/latest.json", entry)

# Clear existing history and push new history as a bulk PUT
req_del = urllib.request.Request(f"{url}/sensors/history.json?auth={auth}", method='DELETE')
try:
    urllib.request.urlopen(req_del)
except:
    pass

push_data("sensors/history.json", history)

print("Data injection complete! Sent 30 days of gradual pollution data.")
