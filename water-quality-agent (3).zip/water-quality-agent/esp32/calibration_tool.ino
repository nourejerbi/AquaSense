/*
 * Water Quality AI Agent — Sensor Calibration Tool
 * ==================================================
 * Run this sketch BEFORE the main firmware to calibrate each sensor.
 * Open Serial Monitor at 115200 baud and follow the prompts.
 *
 * Saves calibration to ESP32 NVS (non-volatile storage) —
 * the main firmware reads these values automatically.
 */

#include <Arduino.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>

#define PIN_PH         34
#define PIN_TURBIDITY  35
#define PIN_DO         32
#define PIN_TDS        33
#define PIN_NITRATE    36
#define PIN_DS18B20    4

Preferences      prefs;
OneWire          oneWire(PIN_DS18B20);
DallasTemperature tempSensor(&oneWire);

// ─── Helper ───────────────────────────────────────────────────────────────────

float avgVoltage(int pin, int n = 50) {
  long sum = 0;
  for (int i = 0; i < n; i++) { sum += analogRead(pin); delay(10); }
  return (sum / (float)n) / 4095.0 * 3.3;
}

void waitEnter(const char* msg) {
  Serial.println(msg);
  Serial.println("Press ENTER when ready...");
  while (!Serial.available()) delay(100);
  while (Serial.available()) Serial.read();
}

// ─── Calibration routines ─────────────────────────────────────────────────────

void calibratePH() {
  Serial.println("\n====== pH CALIBRATION ======");
  Serial.println("You need: pH 4.0 buffer, pH 7.0 buffer, distilled water, soft cloth");

  waitEnter("Step 1: Rinse probe with distilled water. Dip into pH 4.0 buffer solution.");
  delay(2000);
  float v4 = avgVoltage(PIN_PH);
  Serial.printf("  pH 4.0 voltage: %.4f V\n", v4);

  waitEnter("Step 2: Rinse probe. Dip into pH 7.0 buffer solution.");
  delay(2000);
  float v7 = avgVoltage(PIN_PH);
  Serial.printf("  pH 7.0 voltage: %.4f V\n", v7);

  if (abs(v4 - v7) < 0.05) {
    Serial.println("ERROR: Voltages too close. Check wiring or replace probe.");
    return;
  }

  prefs.begin("calibration", false);
  prefs.putFloat("ph_v4", v4);
  prefs.putFloat("ph_v7", v7);
  prefs.end();
  Serial.printf("  Saved: pH_V4=%.4f, pH_V7=%.4f\n", v4, v7);
  Serial.println("pH calibration DONE ✓");
}

void calibrateTurbidity() {
  Serial.println("\n====== TURBIDITY CALIBRATION ======");
  Serial.println("You need: distilled water (0 NTU reference), 100 NTU standard");

  waitEnter("Step 1: Dip sensor into distilled water (0 NTU).");
  delay(2000);
  float v0 = avgVoltage(PIN_TURBIDITY);
  Serial.printf("  0 NTU voltage: %.4f V\n", v0);

  waitEnter("Step 2: Dip sensor into 100 NTU standard solution.");
  delay(2000);
  float v100 = avgVoltage(PIN_TURBIDITY);
  Serial.printf("  100 NTU voltage: %.4f V\n", v100);

  prefs.begin("calibration", false);
  prefs.putFloat("turb_v0",   v0);
  prefs.putFloat("turb_v100", v100);
  prefs.end();
  Serial.println("Turbidity calibration DONE ✓");
}

void calibrateDO() {
  Serial.println("\n====== DISSOLVED OXYGEN CALIBRATION ======");
  Serial.println("You need: air-saturated water (pour water back and forth for 5 min)");

  waitEnter("Dip sensor into air-saturated water. Wait 30 seconds for stabilization.");
  delay(30000);
  float vAir = avgVoltage(PIN_DO);
  tempSensor.requestTemperatures();
  float tempC = tempSensor.getTempCByIndex(0);
  if (tempC == DEVICE_DISCONNECTED_C) tempC = 25.0;

  // DO saturation at current temperature
  float doSat = 14.62 - 0.3898 * tempC + 0.006969 * tempC * tempC
                - 0.00005696 * tempC * tempC * tempC;

  Serial.printf("  Air voltage: %.4f V at %.1f °C\n", vAir, tempC);
  Serial.printf("  DO saturation at this temp: %.2f mg/L\n", doSat);

  prefs.begin("calibration", false);
  prefs.putFloat("do_vair",  vAir);
  prefs.putFloat("do_sat",   doSat);
  prefs.end();
  Serial.println("DO calibration DONE ✓");
}

void calibrateTDS() {
  Serial.println("\n====== TDS / CONDUCTIVITY CALIBRATION ======");
  Serial.println("You need: 1413 µS/cm standard solution (common conductivity standard)");

  waitEnter("Dip sensor into standard 1413 µS/cm solution.");
  delay(5000);
  float vStd = avgVoltage(PIN_TDS);
  tempSensor.requestTemperatures();
  float tempC = tempSensor.getTempCByIndex(0);
  if (tempC == DEVICE_DISCONNECTED_C) tempC = 25.0;

  Serial.printf("  Standard voltage: %.4f V at %.1f °C\n", vStd, tempC);

  prefs.begin("calibration", false);
  prefs.putFloat("tds_vstd", vStd);
  prefs.putFloat("tds_std",  1413.0);
  prefs.putFloat("tds_temp", tempC);
  prefs.end();
  Serial.println("TDS calibration DONE ✓");
}

void calibrateNitrate() {
  Serial.println("\n====== NITRATE CALIBRATION ======");
  Serial.println("You need: 0 mg/L (distilled water) and 50 mg/L nitrate standard");

  waitEnter("Step 1: Dip sensor into distilled water.");
  delay(3000);
  float v0 = avgVoltage(PIN_NITRATE);
  Serial.printf("  0 mg/L voltage: %.4f V\n", v0);

  waitEnter("Step 2: Dip sensor into 50 mg/L nitrate standard.");
  delay(3000);
  float v50 = avgVoltage(PIN_NITRATE);
  Serial.printf("  50 mg/L voltage: %.4f V\n", v50);

  prefs.begin("calibration", false);
  prefs.putFloat("nit_v0",  v0);
  prefs.putFloat("nit_v50", v50);
  prefs.end();
  Serial.println("Nitrate calibration DONE ✓");
}

void printCurrentCalibration() {
  prefs.begin("calibration", true);
  Serial.println("\n====== SAVED CALIBRATION VALUES ======");
  Serial.printf("pH:       V(4.0)=%.4f  V(7.0)=%.4f\n",
    prefs.getFloat("ph_v4", 0), prefs.getFloat("ph_v7", 0));
  Serial.printf("Turbidity: V(0)=%.4f  V(100)=%.4f\n",
    prefs.getFloat("turb_v0", 0), prefs.getFloat("turb_v100", 0));
  Serial.printf("DO:       V(air)=%.4f  Sat=%.2f mg/L\n",
    prefs.getFloat("do_vair", 0), prefs.getFloat("do_sat", 0));
  Serial.printf("TDS:      V(std)=%.4f  Std=%.0f µS/cm\n",
    prefs.getFloat("tds_vstd", 0), prefs.getFloat("tds_std", 0));
  Serial.printf("Nitrate:  V(0)=%.4f  V(50)=%.4f\n",
    prefs.getFloat("nit_v0", 0), prefs.getFloat("nit_v50", 0));
  prefs.end();
}

// ─── Setup / Loop ─────────────────────────────────────────────────────────────

void setup() {
  Serial.begin(115200);
  delay(1000);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  tempSensor.begin();

  Serial.println("\n=========================================");
  Serial.println("  Water Quality Sensor Calibration Tool");
  Serial.println("=========================================");
  Serial.println("Select sensor to calibrate:");
  Serial.println("  1 - pH");
  Serial.println("  2 - Turbidity");
  Serial.println("  3 - Dissolved Oxygen");
  Serial.println("  4 - TDS / Conductivity");
  Serial.println("  5 - Nitrates");
  Serial.println("  6 - Print current calibration");
  Serial.println("  A - Calibrate ALL sensors");
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();
    switch (c) {
      case '1': calibratePH();        break;
      case '2': calibrateTurbidity(); break;
      case '3': calibrateDO();        break;
      case '4': calibrateTDS();       break;
      case '5': calibrateNitrate();   break;
      case '6': printCurrentCalibration(); break;
      case 'A': case 'a':
        calibratePH();
        calibrateTurbidity();
        calibrateDO();
        calibrateTDS();
        calibrateNitrate();
        Serial.println("\n✓ All sensors calibrated!");
        printCurrentCalibration();
        break;
    }
    Serial.println("\nSelect another sensor or 'A' for all:");
  }
}
