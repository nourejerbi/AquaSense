
// ─── State ─────────────────────────────────────────────────────────────────

const SENSORS = {
  ph:      { label:'pH',           unit:'',       safeMin:6.5, safeMax:8.5,  min:0,   max:14,   decimals:2, color:'#58a6ff' },
  turb:    { label:'Turbidity',    unit:'NTU',    safeMin:0,   safeMax:4,    min:0,   max:30,   decimals:1, color:'#d29922' },
  do:      { label:'Dissolved O₂', unit:'mg/L',   safeMin:6,   safeMax:14,   min:0,   max:14,   decimals:1, color:'#3fb950' },
  temp:    { label:'Temperature',  unit:'°C',     safeMin:10,  safeMax:30,   min:0,   max:50,   decimals:1, color:'#f85149' },
  cond:    { label:'Conductivity', unit:'µS/cm',  safeMin:0,   safeMax:800,  min:0,   max:2000, decimals:0, color:'#bc8cff' },
  nitrate: { label:'Nitrates',     unit:'mg/L',   safeMin:0,   safeMax:50,   min:0,   max:100,  decimals:1, color:'#ffa657' }
};

const state = {
  values:  { ph:7.2, turb:3.1, do:8.4, temp:22.1, cond:420, nitrate:8.2 },
  history: { ph:[], turb:[], do:[], temp:[], cond:[], nitrate:[] },
  labels:  [],
  log:     [],
  readCount: 0,
  simRunning: false,
  simInterval: null,
  polluting: false,
  polluteTick: 0,
  fbInterval: null,
  fbConnected: false,
  charts: {}
};

// ─── Init ──────────────────────────────────────────────────────────────────

function init() {
  const savedKey = localStorage.getItem('geminiApiKey');
  if (savedKey) document.getElementById('gemini-apikey').value = savedKey;

  buildSensorGrid();
  initCharts();
  // history will be loaded from Firebase when connected
  updateAllCards();
  updateAlerts();
  updateCharts();
  renderHistory();
  updateUptime();
}

// ─── Sensor grid ───────────────────────────────────────────────────────────

function buildSensorGrid() {
  const grid = document.getElementById('sensor-grid');
  grid.innerHTML = Object.entries(SENSORS).map(([k, s]) => `
    <div class="sensor-card" id="card-${k}">
      <div class="s-badge badge-safe" id="badge-${k}">Safe</div>
      <div class="s-label">${s.label}</div>
      <div class="s-value" id="val-${k}">${state.values[k].toFixed(s.decimals)}</div>
      <div class="s-unit">${s.unit}</div>
      <div class="s-range" id="range-${k}" style="color:var(--safe-txt)">Within safe range</div>
      <div class="history-bars" id="hist-${k}"></div>
      <div class="s-bar" id="bar-${k}"></div>
    </div>`).join('');
}

function updateCard(key, value) {
  const s = SENSORS[key];
  state.values[key] = Math.round(value * 100) / 100;
  const v = state.values[key];

  document.getElementById('val-'+key).textContent = v.toFixed(s.decimals);

  const safe   = v >= s.safeMin && v <= s.safeMax;
  const danger = isDanger(key, v);
  const badge  = document.getElementById('badge-'+key);
  const range  = document.getElementById('range-'+key);
  const bar    = document.getElementById('bar-'+key);

  badge.className = 's-badge ' + (danger ? 'badge-danger' : safe ? 'badge-safe' : 'badge-warn');
  badge.textContent = danger ? 'Danger' : safe ? 'Safe' : 'Warning';
  range.style.color = danger ? 'var(--danger-txt)' : safe ? 'var(--safe-txt)' : 'var(--warn-txt)';
  range.textContent = safe ? 'Within safe range' : `Out of range (${s.safeMin}–${s.safeMax} ${s.unit})`;

  const pct = Math.min(100, Math.max(2, (v - s.min) / (s.max - s.min) * 100));
  bar.style.width = pct + '%';
  bar.style.background = danger ? 'var(--danger-txt)' : safe ? 'var(--safe-txt)' : 'var(--warn-txt)';

  renderMiniHistory(key);
}

function isDanger(k, v) {
  if (k==='ph')      return v < 5.5 || v > 9.5;
  if (k==='turb')    return v > 15;
  if (k==='do')      return v < 3;
  if (k==='cond')    return v > 1500;
  if (k==='nitrate') return v > 80;
  return false;
}

function updateAllCards() {
  Object.keys(SENSORS).forEach(k => updateCard(k, state.values[k]));
}

function renderMiniHistory(k) {
  const el = document.getElementById('hist-'+k);
  if (!el) return;
  const h = state.history[k].slice(-12);
  const s = SENSORS[k];
  const mx = Math.max(...h) + 0.01, mn = Math.min(...h) - 0.01;
  el.innerHTML = h.map(v => {
    const pct = Math.max(8, Math.round((v - mn) / (mx - mn) * 100));
    const safe = v >= s.safeMin && v <= s.safeMax;
    return `<div class="h-bar" style="height:${pct}%;background:${safe?'#238636':'#b62324'}"></div>`;
  }).join('');
}

// ─── Alerts ────────────────────────────────────────────────────────────────

function updateAlerts() {
  const issues = [];
  const v = state.values;
  if (v.ph < 6.5 || v.ph > 8.5) issues.push({ cls: isDanger('ph',v.ph)?'a-danger':'a-warn', msg:`pH ${v.ph} — safe range 6.5–8.5` });
  if (v.turb > 4)              issues.push({ cls: isDanger('turb',v.turb)?'a-danger':'a-warn', msg:`Turbidity ${v.turb} NTU — exceeds 4 NTU limit` });
  if (v.do < 6)                issues.push({ cls: isDanger('do',v.do)?'a-danger':'a-warn', msg:`Dissolved O₂ ${v.do} mg/L — low, aquatic life at risk` });
  if (v.temp < 10||v.temp > 30) issues.push({ cls:'a-warn', msg:`Temperature ${v.temp}°C — outside 10–30°C range` });
  if (v.cond > 800)            issues.push({ cls: isDanger('cond',v.cond)?'a-danger':'a-warn', msg:`Conductivity ${v.cond} µS/cm — high dissolved solids` });
  if (v.nitrate > 50)          issues.push({ cls: isDanger('nitrate',v.nitrate)?'a-danger':'a-warn', msg:`Nitrates ${v.nitrate} mg/L — eutrophication risk` });

  const box = document.getElementById('alerts-list');
  if (!issues.length) {
    box.innerHTML = '<div class="alert-row a-ok"><i class="ti ti-check"></i> All parameters within safe range</div>';
  } else {
    box.innerHTML = issues.map(i => `<div class="alert-row ${i.cls}"><i class="ti ti-alert-triangle"></i> ${i.msg}</div>`).join('');
  }
}

function computeScore() {
  const v = state.values;
  let score = 100;
  const SENSORS_DEF = [
    { v: v.ph,      min:6.5, max:8.5,  penaltyPerUnit:15 },
    { v: v.turb,    min:0,   max:4,    penaltyPerUnit:5  },
    { v: v.do,      min:6,   max:14,   penaltyPerUnit:10, invertExcess:true },
    { v: v.temp,    min:10,  max:30,   penaltyPerUnit:3  },
    { v: v.cond,    min:0,   max:800,  penaltyPerUnit:0.02 },
    { v: v.nitrate, min:0,   max:50,   penaltyPerUnit:0.5 }
  ];
  SENSORS_DEF.forEach(s => {
    if (s.v < s.min) score -= (s.min - s.v) * s.penaltyPerUnit;
    else if (s.v > s.max) score -= (s.v - s.max) * s.penaltyPerUnit;
  });
  return Math.max(0, Math.min(100, Math.round(score)));
}

function updateUptime() {
  document.getElementById('uptime-val').textContent = state.readCount + ' readings';
  const score = computeScore();
  document.getElementById('score-val').textContent = score + '/100';
  const scoreCard = document.getElementById('score-card');
  scoreCard.className = 'summary-card ' + (score >= 80 ? 's-safe' : score >= 50 ? 's-warn' : 's-danger');
}

// ─── Push new reading ──────────────────────────────────────────────────────

function pushReading(vals, ts_val) {
  Object.keys(vals).forEach(k => {
    if (SENSORS[k]) {
      state.values[k] = vals[k];
      state.history[k].push(vals[k]);
      if (state.history[k].length > 50) state.history[k].shift();
      updateCard(k, vals[k]);
    }
  });
  const ts = ts_val ? new Date(ts_val * 1000).toLocaleTimeString() : new Date().toLocaleTimeString();
  const dtStr = ts_val ? new Date(ts_val * 1000).toLocaleString() : new Date().toLocaleString();
  
  state.labels.push(ts);
  if (state.labels.length > 50) state.labels.shift();
  state.readCount++;

  const score = computeScore();
  const status = score >= 80 ? 'SAFE' : score >= 50 ? 'WARNING' : 'POLLUTED';
  state.log.unshift({ ts: dtStr, status, ...state.values });
  if (state.log.length > 50) state.log.pop();

  updateAlerts();
  updateCharts();
  renderHistory();
  updateUptime();
  updateNavStatus(status);
  document.getElementById('last-update-nav').textContent = 'Updated ' + ts;
}

// ─── Firebase Connection ───────────────────────────────────────────────────

const FIREBASE_URL = "https://water-quality-agent-b500e-default-rtdb.europe-west1.firebasedatabase.app";
const FIREBASE_API_KEY = "AIzaSyB9Q9Xx2RvOFfkMbMmwPU98H0kgrMLqT5Y";

async function registerUser() {
  const email = document.getElementById('fb-email').value.trim();
  const fb = document.getElementById('fb-feedback');
  if (!email) { fb.style.color='var(--danger-txt)'; fb.textContent='Please enter an email address to register.'; return; }
  
  fb.style.color = 'var(--muted)';
  fb.textContent = 'Registering account...';
  
  // Generate random password (32 chars)
  const array = new Uint8Array(24);
  window.crypto.getRandomValues(array);
  const randomPassword = Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');

  try {
    // 1. Create account
    const signUpRes = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${FIREBASE_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: randomPassword, returnSecureToken: true })
    });
    const signUpData = await signUpRes.json();
    if (!signUpRes.ok) {
      if (signUpData.error?.message === "EMAIL_EXISTS") throw new Error("Account already exists. Please log in or reset password.");
      throw new Error(signUpData.error?.message || 'Registration failed');
    }
    
    // 2. Send password reset email
    await triggerPasswordReset(email);
    
    fb.style.color = 'var(--safe-txt)';
    fb.innerHTML = '<b>Registration successful!</b><br>Please check your email for a link to securely set your password. Then come back and log in.';
  } catch (e) {
    fb.style.color = 'var(--danger-txt)';
    fb.textContent = e.message;
  }
}

async function triggerPasswordReset(email) {
  const resetRes = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${FIREBASE_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ requestType: "PASSWORD_RESET", email })
  });
  if (!resetRes.ok) {
    const errorData = await resetRes.json();
    throw new Error(errorData.error?.message || 'Failed to send password reset email');
  }
}

async function resetPassword() {
  const email = document.getElementById('fb-email').value.trim();
  const fb = document.getElementById('fb-feedback');
  if (!email) { fb.style.color='var(--danger-txt)'; fb.textContent='Please enter your email address to reset password.'; return; }
  
  fb.style.color = 'var(--muted)';
  fb.textContent = 'Sending reset email...';
  
  try {
    await triggerPasswordReset(email);
    fb.style.color = 'var(--safe-txt)';
    fb.textContent = 'Password reset email sent! Please check your inbox.';
  } catch (e) {
    fb.style.color = 'var(--danger-txt)';
    fb.textContent = e.message;
  }
}

function connectFirebase() {
  const url  = FIREBASE_URL;
  const key  = FIREBASE_API_KEY;
  const email= document.getElementById('fb-email').value.trim();
  const pass = document.getElementById('fb-password').value.trim();
  const path = document.getElementById('fb-path').value.trim() || '/sensors/latest';
  const interval = parseInt(document.getElementById('fb-interval').value);
  const fb   = document.getElementById('fb-feedback');

  if (!email || !pass) { fb.style.color='var(--danger-txt)'; fb.textContent='Please enter your email and password.'; return; }
  if (state.fbInterval) clearInterval(state.fbInterval);

  // Wrap in async IIFE to allow await for history
  (async () => {
    fb.style.color = 'var(--muted)';
    fb.textContent = 'Authenticating…';
    
    let idToken = null;
    try {
      const authRes = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${key}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass, returnSecureToken: true })
      });
      const authData = await authRes.json();
      if (!authRes.ok) throw new Error(authData.error?.message || 'Authentication failed');
      idToken = authData.idToken;
    } catch(e) {
      fb.style.color = 'var(--danger-txt)';
      fb.textContent = 'Auth Error: ' + e.message;
      return;
    }

    fb.textContent = 'Connecting…';

  try {
    const histUrl = `${url.replace(/\/$/,'')}/sensors/history.json?auth=${idToken}&orderBy="$key"&limitToLast=50`;
    const histRes = await fetch(histUrl);
    if (histRes.ok) {
      const histData = await histRes.json();
      if (histData && typeof histData === 'object') {
        state.history = { ph:[], turb:[], do:[], temp:[], cond:[], nitrate:[] };
        state.labels = [];
        state.log = [];
        state.readCount = 0;
        
        const sortedKeys = Object.keys(histData).sort();
        sortedKeys.forEach(k => {
          const d = histData[k];
          const mapped = {};
          if (d.ph             != null) mapped.ph      = parseFloat(d.ph);
          if (d.turbidity      != null) mapped.turb    = parseFloat(d.turbidity);
          if (d.dissolved_oxygen!=null) mapped.do      = parseFloat(d.dissolved_oxygen);
          if (d.temperature    != null) mapped.temp    = parseFloat(d.temperature);
          if (d.conductivity   != null) mapped.cond    = parseFloat(d.conductivity);
          if (d.nitrates       != null) mapped.nitrate = parseFloat(d.nitrates);
          if (Object.keys(mapped).length > 0) {
            pushReading(mapped, d.timestamp);
          }
        });
      }
    }
  } catch(e) {
    console.error("Failed to load history", e);
  }

  const poll = async () => {
    try {
      const fullUrl = `${url.replace(/\/$/,'')}${path}.json?auth=${idToken}`;
      const res  = await fetch(fullUrl);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (!data || typeof data !== 'object') throw new Error('No data at path');

      const mapped = {};
      if (data.ph             != null) mapped.ph      = parseFloat(data.ph);
      if (data.turbidity      != null) mapped.turb    = parseFloat(data.turbidity);
      if (data.dissolved_oxygen!=null) mapped.do      = parseFloat(data.dissolved_oxygen);
      if (data.temperature    != null) mapped.temp    = parseFloat(data.temperature);
      if (data.conductivity   != null) mapped.cond    = parseFloat(data.conductivity);
      if (data.nitrates       != null) mapped.nitrate = parseFloat(data.nitrates);

      if (Object.keys(mapped).length > 0) {
        pushReading(mapped);
        state.fbConnected = true;
        document.getElementById('live-subtitle').textContent = 'Live data from Firebase — ESP32 sensor stream';
      }
    } catch(e) {
      console.error('Poll Error: ' + e.message);
    }
  };
  poll();
  state.fbInterval = setInterval(poll, interval);
  document.getElementById('login-overlay').style.display = 'none';
  })();
}

function disconnectFirebase() {
  if (state.fbInterval) clearInterval(state.fbInterval);
  state.fbConnected = false;
  document.getElementById('login-overlay').style.display = 'flex';
  document.getElementById('fb-feedback').textContent = '';
}

// ─── AI Agent ──────────────────────────────────────────────────────────────

async function analyzeWithAI() {
  const btns = ['analyze-btn','analyze-btn2','predict-btn'];
  btns.forEach(id => { const b=document.getElementById(id); if(b){b.disabled=true; b.innerHTML='<span class="spinner"></span> Analyzing…'; }});

  const v = state.values;
  const trendLines = Object.entries(SENSORS).map(([k,s]) => {
    const h = state.history[k].slice(-5);
    if (h.length < 2) return '';
    const trend = h[h.length-1] - h[0] > 0 ? '↑ rising' : '↓ falling';
    return `  ${s.label}: ${v[k === 'do' ? 'do' : k === 'nitrate' ? 'nitrate' : k] ?? v[k]} ${s.unit} (${trend})`;
  }).join('\n');

  const prompt = `You are a professional water quality AI agent analyzing real-time sensor data from an ESP32 monitoring system.

Current sensor readings:
  pH:               ${v.ph}         (safe: 6.5–8.5)
  Turbidity:        ${v.turb} NTU   (safe: <4 NTU)
  Dissolved Oxygen: ${v.do} mg/L    (safe: >6 mg/L)
  Temperature:      ${v.temp} °C    (safe: 10–30°C)
  Conductivity:     ${v.cond} µS/cm (safe: <800 µS/cm)
  Nitrates:         ${v.nitrate} mg/L (safe: <50 mg/L)

Recent trends (last 5 readings):
${trendLines}

Respond with EXACTLY this structure (use the section headers as written):

CLASSIFICATION:
[One paragraph: state clearly if the water is SAFE, MILDLY POLLUTED, or POLLUTED. Cite specific out-of-range values. Give a confidence level.]

CAUSES:
[If issues exist, identify the most likely pollution sources based on the parameter pattern. If safe, note what could cause future issues given the trends.]

PREDICTION_1H: LOW|MEDIUM|HIGH
[One sentence explaining why]

PREDICTION_6H: LOW|MEDIUM|HIGH
[One sentence explaining why]

PREDICTION_24H: LOW|MEDIUM|HIGH
[One sentence explaining why]

RECOMMENDATIONS:
1. [Specific action]
2. [Specific action]
3. [Specific action]

Keep each section concise and technical. No preamble.`;

  const apiKey = document.getElementById('gemini-apikey').value.trim();
  if (!apiKey) {
    console.error('Error: Please provide a Gemini API Key in the Setup tab.');
    btns.forEach(id => {
      const b = document.getElementById(id);
      if (b) {
        b.disabled = false;
        b.innerHTML = `<i class="ti ti-sparkles"></i> ${id === 'predict-btn' ? 'Update predictions' : 'Analyze with AI'}`;
      }
    });
    return;
  }
  localStorage.setItem('geminiApiKey', apiKey);

  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 1000 }
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || 'Gemini API Error');
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response';
    parseAIResponse(text);
  } catch(e) {
    console.error('Prediction Error: ' + e.message);
  }

  btns.forEach(id => {
    const b = document.getElementById(id);
    if (b) {
      b.disabled = false;
      const icon = id === 'predict-btn' ? 'ti-sparkles' : 'ti-sparkles';
      b.innerHTML = `<i class="ti ${icon}"></i> ${id === 'predict-btn' ? 'Update predictions' : 'Analyze with AI'}`;
    }
  });
  document.getElementById('analyze-btn').innerHTML = '<i class="ti ti-sparkles"></i> Analyze with AI';
  document.getElementById('analyze-btn').disabled = false;
}

function parseAIResponse(text) {
  // We only parse predictions now since classification is handled by the chat interface
  const p1 = text.match(/PREDICTION_1H:\n?(.*)\n/i)?.[1]?.trim().split(' ')[0] || 'UNKNOWN';
  const p6 = text.match(/PREDICTION_6H:\n?(.*)\n/i)?.[1]?.trim().split(' ')[0] || 'UNKNOWN';
  const p24= text.match(/PREDICTION_24H:\n?(.*)\n/i)?.[1]?.trim().split(' ')[0] || 'UNKNOWN';

  const n1 = text.match(/PREDICTION_1H:.*\n(.*)/)?.[1]?.trim() || '';
  const n6 = text.match(/PREDICTION_6H:.*\n(.*)/)?.[1]?.trim() || '';
  const n24= text.match(/PREDICTION_24H:.*\n(.*)/)?.[1]?.trim() || '';

  const riskClass = r => r.toUpperCase()==='HIGH'?'risk-high':r.toUpperCase()==='MEDIUM'?'risk-med':'risk-low';
  document.getElementById('pred-1h').className  = 'pred-risk ' + riskClass(p1);
  document.getElementById('pred-6h').className  = 'pred-risk ' + riskClass(p6);
  document.getElementById('pred-24h').className = 'pred-risk ' + riskClass(p24);
  document.getElementById('pred-1h').textContent  = p1 + ' RISK';
  document.getElementById('pred-6h').textContent  = p6 + ' RISK';
  document.getElementById('pred-24h').textContent = p24 + ' RISK';
  document.getElementById('pred-1h-note').textContent  = n1;
  document.getElementById('pred-6h-note').textContent  = n6;
  document.getElementById('pred-24h-note').textContent = n24;
}

// ─── AI Co-Pilot Chat ──────────────────────────────────────────────────────

state.chatHistory = [];

async function sendChatMessage(presetMsg = null) {
  const inputEl = document.getElementById('chat-input');
  const msgText = presetMsg || inputEl.value.trim();
  if (!msgText) return;
  
  const apiKey = document.getElementById('gemini-apikey').value.trim();
  if (!apiKey) {
    alert("Please enter your Gemini API Key in the Setup tab first.");
    return;
  }

  // Clear input
  inputEl.value = '';
  
  // Append user message to UI
  const historyEl = document.getElementById('chat-history');
  historyEl.innerHTML += \`<div class="chat-msg user-msg">
    <div class="msg-avatar"><i class="ti ti-user"></i></div>
    <div class="msg-content">\${msgText}</div>
  </div>\`;
  historyEl.scrollTop = historyEl.scrollHeight;

  // Show typing indicator
  const typingId = 'typing-' + Date.now();
  historyEl.innerHTML += \`<div class="chat-msg ai-msg" id="\${typingId}">
    <div class="msg-avatar"><i class="ti ti-robot"></i></div>
    <div class="msg-content"><span class="spinner"></span> Analyzing data...</div>
  </div>\`;
  historyEl.scrollTop = historyEl.scrollHeight;
  
  // Format log data for context
  let logCsv = "ts,ph,turb,do,temp,cond,nitrate\\n";
  state.log.slice(0, 50).forEach(r => {
    logCsv += \`\${r.ts},\${r.ph},\${r.turb},\${r.do},\${r.temp},\${r.cond},\${r.nitrate}\\n\`;
  });
  
  const systemPrompt = \`You are an AI Water Quality Co-Pilot monitoring live ESP32 sensors. 
You are speaking directly to the facility manager. Use a helpful, analytical, and professional tone.
Output in Markdown format (use **bold** for metrics, bullet points for lists).
Here is the most recent historical sensor data (newest first):
\` + logCsv + \`

Safe ranges: pH (6.5-8.5), Turbidity (<4), DO (>6), Temp (10-30), Cond (<800), Nitrates (<50).
If data is outside safe ranges, explicitly call it out.\`;

  // Build payload
  state.chatHistory.push({ role: "user", parts: [{ text: msgText }] });
  
  // To inject system instructions, we prepend it to the history (Gemini REST API way without systemInstruction field for simplicity, just making the first message have context)
  let apiContents = [];
  if (state.chatHistory.length === 1) {
    apiContents.push({ role: "user", parts: [{ text: systemPrompt + "\\n\\nUser Request: " + msgText }] });
  } else {
    // For subsequent turns, we just send the history. But to keep context fresh without blowing up tokens, 
    // we'll inject the fresh data into the latest user prompt.
    const lastMsg = state.chatHistory[state.chatHistory.length - 1].parts[0].text;
    apiContents = [...state.chatHistory];
    apiContents[apiContents.length - 1] = { 
      role: "user", 
      parts: [{ text: "LATEST LIVE SENSOR DATA:\\n" + logCsv + "\\n\\nUser: " + lastMsg }] 
    };
  }

  try {
    const res = await fetch(\`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\${apiKey}\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: apiContents })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || 'API Error');
    
    const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text || "No response.";
    state.chatHistory.push({ role: "model", parts: [{ text: replyText }] });
    
    const typingEl = document.getElementById(typingId);
    if (typingEl) {
      typingEl.querySelector('.msg-content').innerHTML = marked.parse(replyText);
    }
  } catch (err) {
    const typingEl = document.getElementById(typingId);
    if (typingEl) {
      typingEl.querySelector('.msg-content').innerHTML = \`<span style="color:var(--danger-txt)">Error: \${err.message}</span>\`;
    }
    state.chatHistory.pop(); // Remove the user message that failed
  }
  historyEl.scrollTop = historyEl.scrollHeight;
}


// ─── Charts ────────────────────────────────────────────────────────────────

function initCharts() {
  const defaults = {
    type: 'line',
    options: {
      responsive: true,
      animation: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color:'#7d8590', maxTicksLimit:8, font:{size:11} }, grid: { color:'#21262d' } },
        y: { ticks: { color:'#7d8590', font:{size:11} }, grid: { color:'#21262d' } }
      }
    }
  };
  const makeChart = (id, color, safeMin, safeMax) => new Chart(document.getElementById(id), {
    ...defaults,
    data: {
      labels: [],
      datasets: [
        { data: [], borderColor: color, borderWidth: 1.5, pointRadius: 0, tension: 0.3, fill: false },
        { data: [], borderColor: '#238636', borderWidth: 1, borderDash:[4,4], pointRadius:0, fill:false },
        { data: [], borderColor: '#b62324', borderWidth: 1, borderDash:[4,4], pointRadius:0, fill:false }
      ]
    }
  });

  state.charts.ph   = makeChart('chart-ph',   '#58a6ff', 6.5, 8.5);
  state.charts.turb = makeChart('chart-turb', '#d29922', 0,   4);
  state.charts.do   = makeChart('chart-do',   '#3fb950', 6,   14);
  state.charts.cond = makeChart('chart-cond', '#bc8cff', 0,   800);
}

function updateCharts() {
  const chartMap = { ph: state.charts.ph, turb: state.charts.turb, do: state.charts.do, cond: state.charts.cond };
  const safeLine = { ph:[6.5,8.5], turb:[0,4], do:[6,14], cond:[0,800] };
  Object.entries(chartMap).forEach(([k, chart]) => {
    if (!chart) return;
    chart.data.labels = state.labels;
    chart.data.datasets[0].data = state.history[k];
    chart.data.datasets[1].data = state.labels.map(() => safeLine[k][0]);
    chart.data.datasets[2].data = state.labels.map(() => safeLine[k][1]);
    chart.update('none');
  });
}

// ─── History ───────────────────────────────────────────────────────────────

function renderHistory() {
  const body = document.getElementById('history-body');
  body.innerHTML = state.log.map(r => {
    const cls = r.status === 'SAFE' ? 'safe' : r.status === 'WARNING' ? 'warn' : 'danger';
    const tagCls = cls === 'safe' ? 'badge-safe' : cls === 'warn' ? 'badge-warn' : 'badge-danger';
    return `<div class="history-row-item">
      <span>${r.ts}</span>
      <span><span class="status-tag ${tagCls}">${r.status}</span></span>
      <span>${r.ph?.toFixed(2)??'—'}</span>
      <span>${r.turb?.toFixed(1)??'—'}</span>
      <span>${r.do?.toFixed(1)??'—'}</span>
      <span>${r.temp?.toFixed(1)??'—'}</span>
      <span>${r.cond?.toFixed(0)??'—'}</span>
      <span>${r.nitrate?.toFixed(1)??'—'}</span>
    </div>`;
  }).join('');
}

function clearHistory() {
  state.log = [];
  renderHistory();
}

// ─── Nav / Status ──────────────────────────────────────────────────────────

function updateNavStatus(status) {
  const pill = document.getElementById('global-status');
  const txt  = document.getElementById('global-status-text');
  pill.className = 'status-pill ' + (status==='SAFE'?'safe':status==='WARNING'?'warn':'danger');
  txt.textContent = status;
}

function showPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('panel-'+name)?.classList.add('active');
  event.currentTarget.classList.add('active');
}

// ─── Export ────────────────────────────────────────────────────────────────

function exportCSV() {
  const headers = 'Timestamp,Status,pH,Turbidity(NTU),DO(mg/L),Temperature(°C),Conductivity(µS/cm),Nitrates(mg/L)';
  const rows = state.log.map(r =>
    `"${r.ts}",${r.status},${r.ph?.toFixed(2)},${r.turb?.toFixed(1)},${r.do?.toFixed(1)},${r.temp?.toFixed(1)},${r.cond?.toFixed(0)},${r.nitrate?.toFixed(1)}`
  );
  const csv = [headers, ...rows].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], {type:'text/csv'}));
  a.download = 'water_quality_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
}

init();
